import os
import logging
import numpy as np
import onnxruntime as ort
from PIL import Image
import cv2
from flask import Flask, request, jsonify, render_template, send_file
import io
import time
from typing import Dict, List, Tuple, Optional

# ������־
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ModelManager:
    """ģ�͹�����������ģ�͵ļ��ء�Ԥ�Ⱥ�����"""
    
    def __init__(self, model_path: str, providers: List[str]):
        self.model_path = model_path
        self.providers = providers
        self.session = None
        self.input_name = None
        self.output_name = None
        self.load_model()
        
    def load_model(self):
        """����ONNXģ�Ͳ�Ԥ��"""
        try:
            logger.info(f"���ڼ���ģ��: {self.model_path}")
            
            # ���������Ự
            self.session = ort.InferenceSession(
                self.model_path, 
                providers=self.providers
            )
            
            # ��ȡ���������Ϣ
            model_inputs = self.session.get_inputs()
            model_outputs = self.session.get_outputs()
            
            self.input_name = model_inputs[0].name
            self.output_name = model_outputs[0].name
            
            logger.info(f"ģ������: {self.input_name}, ��״: {model_inputs[0].shape}")
            logger.info(f"ģ�����: {self.output_name}, ��״: {model_outputs[0].shape}")
            
            # ģ��Ԥ��
            self._warm_up()
            logger.info("ģ�ͼ������!")
            
        except Exception as e:
            logger.error(f"ģ�ͼ���ʧ��: {str(e)}")
            raise
    
    def _warm_up(self):
        """Ԥ��ģ�ͣ���ʼ������ʱ����"""
        dummy_input = np.random.randn(1, 3, 224, 224).astype(np.float32)
        _ = self.session.run([self.output_name], {self.input_name: dummy_input})
    
    def preprocess_image(self, image_data: bytes) -> np.ndarray:
        """Ԥ����ͼ������"""
        try:
            # ����1: ʹ��OpenCV
            image_array = np.frombuffer(image_data, np.uint8)
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # �����ߴ�
            image = cv2.resize(image, (224, 224))
            
            # ��һ�� [0, 255] -> [0, 1]
            image = image.astype(np.float32) / 255.0
            
            # ��׼�� (ImageNetͳ����)
            mean = np.array([0.485, 0.456, 0.406])
            std = np.array([0.229, 0.224, 0.225])
            image = (image - mean) / std
            
            # ת��ά��: HWC -> CHW
            image = image.transpose(2, 0, 1)
            
            # ��������ά��
            image = np.expand_dims(image, axis=0)
            
            return image
            
        except Exception as e:
            logger.error(f"ͼ��Ԥ����ʧ��: {str(e)}")
            raise
    
    def predict(self, image_data: bytes) -> Dict:
        """ִ������Ԥ��"""
        start_time = time.time()
        
        try:
            # Ԥ����
            preprocess_time = time.time()
            input_tensor = self.preprocess_image(image_data)
            preprocess_time = time.time() - preprocess_time
            
            # ����
            inference_start = time.time()
            outputs = self.session.run([self.output_name], {self.input_name: input_tensor})
            inference_time = time.time() - inference_start
            
            # ����
            postprocess_start = time.time()
            predictions = self._postprocess(outputs[0])
            postprocess_time = time.time() - postprocess_start
            
            total_time = time.time() - start_time
            
            return {
                'predictions': predictions,
                'timing': {
                    'preprocess_ms': round(preprocess_time * 1000, 2),
                    'inference_ms': round(inference_time * 1000, 2),
                    'postprocess_ms': round(postprocess_time * 1000, 2),
                    'total_ms': round(total_time * 1000, 2)
                },
                'status': 'success'
            }
            
        except Exception as e:
            logger.error(f"����ʧ��: {str(e)}")
            return {
                'error': str(e),
                'status': 'error'
            }
    
    def _postprocess(self, outputs: np.ndarray) -> List[Dict]:
        """��������ģ�����ת��Ϊ�ɶ����"""
        # Ӧ��softmax��ȡ����
        exp_outputs = np.exp(outputs - np.max(outputs))
        probabilities = exp_outputs / np.sum(exp_outputs)
        
        # ��ȡTop-5Ԥ����
        top5_indices = np.argsort(probabilities[0])[-5:][::-1]
        top5_probabilities = probabilities[0][top5_indices]
        
        # ����Ӧ��ʹ��ImageNet����ǩ
        # Ϊ��ʾʹ�������ǩ
        results = []
        for i, (idx, prob) in enumerate(zip(top5_indices, top5_probabilities)):
            results.append({
                'rank': i + 1,
                'class_id': int(idx),
                'class_name': f'Class_{idx}',  # ʵ��Ӧ����Ӧʹ����ʵ��ǩ
                'confidence': float(prob),
                'confidence_percentage': round(float(prob) * 100, 2)
            })
        
        return results