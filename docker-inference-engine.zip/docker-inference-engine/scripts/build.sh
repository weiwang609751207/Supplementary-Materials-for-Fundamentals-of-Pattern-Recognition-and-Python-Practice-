#!/bin/bash

set -e

# ��ɫ����
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ��־����
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# ��������Ƿ����
check_command() {
    if ! command -v $1 &> /dev/null; then
        log_error "$1 is not installed. Please install $1 first."
        exit 1
    fi
}

# ����ģ��
download_model() {
    log "Downloading ResNet50 ONNX model..."
    python scripts/download_model.py
    if [ $? -eq 0 ]; then
        log "Model downloaded successfully."
    else
        log_error "Failed to download model."
        exit 1
    fi
}

# ����CPU����
build_cpu() {
    log "Building CPU inference image..."
    docker build -f docker/Dockerfile.cpu -t inference-engine:cpu-latest .
    if [ $? -eq 0 ]; then
        log "CPU image built successfully."
    else
        log_error "Failed to build CPU image."
        exit 1
    fi
}

# ����GPU����
build_gpu() {
    log "Building GPU inference image..."
    docker build -f docker/Dockerfile.gpu -t inference-engine:gpu-latest .
    if [ $? -eq 0 ]; then
        log "GPU image built successfully."
    else
        log_warn "Failed to build GPU image. This might be expected if you don't have GPU support."
    fi
}

# ������
main() {
    log "Starting Docker Inference Engine build process..."
    
    # �������
    check_command docker
    check_command docker-compose
    
    # ����ģ��
    if [ ! -f "models/resnet50.onnx" ]; then
        download_model
    else
        log "Model already exists, skipping download."
    fi
    
    # ��������
    build_cpu
    build_gpu
    
    log "Build process completed successfully!"
    log ""
    log "You can now start the services with:"
    log "  docker-compose -f docker/docker-compose.yml up -d"
    log ""
    log "Services will be available at:"
    log "  - CPU Inference: http://localhost:8000"
    log "  - GPU Inference: http://localhost:8001"
    log "  - Nginx Load Balancer: http://localhost:80"
    log "  - Prometheus: http://localhost:9090"
    log "  - Grafana: http://localhost:3000"
}

# ��������
case "$1" in
    cpu)
        build_cpu
        ;;
    gpu)
        build_gpu
        ;;
    model)
        download_model
        ;;
    *)
        main
        ;;
esac