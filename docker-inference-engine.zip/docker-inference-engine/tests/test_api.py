#!/usr/bin/env python3
"""
API���Խű�
"""

import requests
import json
import time
import cv2
import numpy as np
from pathlib import Path

def test_health(endpoint):
    """���Խ������˵�"""
    print(f"Testing health endpoint: {endpoint}")
    try:
        response = requests.get(f"{endpoint}/health")
        print(f"Status: {response.status_code}")
        print(f"Response: {response.json()}")
        return response.status_code == 200
    except Exception as e:
        print(f"Health check failed: {e}")
        return False

def test_status(endpoint):
    """����״̬�˵�"""
    print(f"Testing status endpoint: {endpoint}")
    try:
        response = requests.get(f"{endpoint}/status")
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"Status check failed: {e}")
        return False

def create_test_image():
    """��������ͼƬ"""
    # ����һ���򵥵Ĳ���ͼƬ
    img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
    cv2.imwrite('test_image.jpg', img)
    return 'test_image.jpg'

def test_predict(endpoint, image_path):
    """����Ԥ��˵�"""
    print(f"Testing predict endpoint: {endpoint}")
    try:
        with open(image_path, 'rb') as f:
            files = {'file': ('test.jpg', f, 'image/jpeg')}
            start_time = time.time()
            response = requests.post(f"{endpoint}/predict", files=files)
            end_time = time.time()
        
        print(f"Status: {response.status_code}")
        print(f"Response Time: {(end_time - start_time)*1000:.2f}ms")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Predictions: {len(result.get('predictions', []))}")
            print(f"Timing: {result.get('timing', {})}")
            return True
        else:
            print(f"Error: {response.text}")
            return False
            
    except Exception as e:
        print(f"Predict test failed: {e}")
        return False

def test_batch_predict(endpoint, image_paths):
    """��������Ԥ��˵�"""
    print(f"Testing batch predict endpoint: {endpoint}")
    try:
        files = []
        for i, path in enumerate(image_paths):
            files.append(('files', (f'test_{i}.jpg', open(path, 'rb'), 'image/jpeg')))
        
        start_time = time.time()
        response = requests.post(f"{endpoint}/batch_predict", files=files)
        end_time = time.time()
        
        print(f"Status: {response.status_code}")
        print(f"Response Time: {(end_time - start_time)*1000:.2f}ms")
        
        if response.status_code == 200:
            result = response.json()
            print(f"Batch ID: {result.get('batch_id')}")
            print(f"Total Files: {result.get('total_files')}")
            return True
        else:
            print(f"Error: {response.text}")
            return False
            
    except Exception as e:
        print(f"Batch predict test failed: {e}")
        return False
    finally:
        # �ر��ļ�
        for file in files:
            file[1][1].close()

def test_metrics(endpoint):
    """����ָ��˵�"""
    print(f"Testing metrics endpoint: {endpoint}")
    try:
        response = requests.get(f"{endpoint}/metrics")
        print(f"Status: {response.status_code}")
        if response.status_code == 200:
            print("Metrics endpoint is working")
            return True
        else:
            print(f"Error: {response.text}")
            return False
    except Exception as e:
        print(f"Metrics test failed: {e}")
        return False

def run_performance_test(endpoint, num_requests=10):
    """�������ܲ���"""
    print(f"Running performance test with {num_requests} requests...")
    
    test_image = create_test_image()
    times = []
    successes = 0
    
    for i in range(num_requests):
        try:
            with open(test_image, 'rb') as f:
                files = {'file': (f'test_{i}.jpg', f, 'image/jpeg')}
                start_time = time.time()
                response = requests.post(f"{endpoint}/predict", files=files)
                end_time = time.time()
            
            if response.status_code == 200:
                times.append((end_time - start_time) * 1000)
                successes += 1
            else:
                print(f"Request {i+1} failed: {response.status_code}")
                
        except Exception as e:
            print(f"Request {i+1} failed with exception: {e}")
    
    # ��������ͼƬ
    Path(test_image).unlink(missing_ok=True)
    
    if times:
        avg_time = sum(times) / len(times)
        min_time = min(times)
        max_time = max(times)
        
        print(f"Performance Results:")
        print(f"  Successful requests: {successes}/{num_requests}")
        print(f"  Average time: {avg_time:.2f}ms")
        print(f"  Min time: {min_time:.2f}ms")
        print(f"  Max time: {max_time:.2f}ms")
        print(f"  Throughput: {1000/avg_time:.2f} requests/second")
    else:
        print("No successful requests to analyze")

def main():
    """�����Ժ���"""
    endpoints = [
        "http://localhost:8000",  # CPU����
        "http://localhost:8001",  # GPU����
        "http://localhost:80",    # Nginx���ؾ���
    ]
    
    # ��������ͼƬ
    test_images = [create_test_image() for _ in range(3)]
    
    for endpoint in endpoints:
        print(f"\n{'='*50}")
        print(f"Testing endpoint: {endpoint}")
        print(f"{'='*50}")
        
        # ���л�������
        health_ok = test_health(endpoint)
        status_ok = test_status(endpoint)
        predict_ok = test_predict(endpoint, test_images[0])
        metrics_ok = test_metrics(endpoint)
        
        if all([health_ok, status_ok, predict_ok, metrics_ok]):
            print(f"? All basic tests passed for {endpoint}")
            
            # ������������
            batch_ok = test_batch_predict(endpoint, test_images)
            if batch_ok:
                print(f"? Batch test passed for {endpoint}")
            
            # �������ܲ���
            run_performance_test(endpoint, num_requests=5)
        else:
            print(f"? Some tests failed for {endpoint}")
    
    # ��������ͼƬ
    for img in test_images:
        Path(img).unlink(missing_ok=True)

if __name__ == "__main__":
    main()