import os
from dataclasses import dataclass
from typing import List, Optional
import logging

@dataclass
class ModelConfig:
    """ģ������"""
    model_path: str = os.getenv('MODEL_PATH', '/app/models/resnet50.onnx')
    input_size: tuple = (224, 224)
    mean: List[float] = (0.485, 0.456, 0.406)
    std: List[float] = (0.229, 0.224, 0.225)
    batch_size: int = int(os.getenv('BATCH_SIZE', '1'))

@dataclass
class ServerConfig:
    """����������"""
    host: str = os.getenv('HOST', '0.0.0.0')
    port: int = int(os.getenv('PORT', '8000'))
    workers: int = int(os.getenv('WORKERS', '1'))
    log_level: str = os.getenv('LOG_LEVEL', 'INFO')
    debug: bool = os.getenv('DEBUG', 'false').lower() == 'true'

@dataclass
class InferenceConfig:
    """��������"""
    providers: List[str] = None
    device: str = os.getenv('DEVICE', 'auto')
    
    def __post_init__(self):
        if self.providers is None:
            if self.device == 'gpu':
                self.providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
            elif self.device == 'cpu':
                self.providers = ['CPUExecutionProvider']
            else:  # auto
                try:
                    import onnxruntime as ort
                    if ort.get_device() == 'GPU':
                        self.providers = ['CUDAExecutionProvider', 'CPUExecutionProvider']
                    else:
                        self.providers = ['CPUExecutionProvider']
                except ImportError:
                    self.providers = ['CPUExecutionProvider']

@dataclass
class Config:
    """������"""
    model: ModelConfig = ModelConfig()
    server: ServerConfig = ServerConfig()
    inference: InferenceConfig = InferenceConfig()
    
    def setup_logging(self):
        """������־"""
        logging.basicConfig(
            level=getattr(logging, self.server.log_level.upper()),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('/app/logs/app.log') if os.path.exists('/app/logs') else logging.StreamHandler()
            ]
        )

config = Config()