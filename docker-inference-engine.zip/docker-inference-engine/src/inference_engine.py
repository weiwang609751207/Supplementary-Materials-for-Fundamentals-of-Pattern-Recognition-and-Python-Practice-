import onnxruntime as ort
import numpy as np
import cv2
import time
import logging
from typing import List, Dict, Any, Optional
import threading
from dataclasses import dataclass
from config import config

logger = logging.getLogger(__name__)

@dataclass
class PredictionResult:
    """Ԥ����������"""
    class_id: int
    class_name: str
    confidence: float
    confidence_percentage: float

class InferenceEngine:
    """��������������"""
    
    def __init__(self, model_path: str, providers: List[str]):
        self.model_path = model_path
        self.providers = providers
        self.session = None
        self.input_name = None
        self.output_name = None
        self.input_shape = None
        self._lock = threading.Lock()  # �̰߳�ȫ
        
        # ����ͳ��
        self.stats = {
            'total_inferences': 0,
            'total_time': 0.0,
            'last_inference_time': 0.0
        }
        
        self.load_model()
    
    def load_model(self):
        """����ONNXģ��"""
        try:
            logger.info(f"Loading model from: {self.model_path}")
            logger.info(f"Available providers: {ort.get_available_providers()}")
            logger.info(f"Using providers: {self.providers}")
            
            # �Ựѡ������
            sess_options = ort.SessionOptions()
            sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            sess_options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
            sess_options.intra_op_num_threads = 1  # ����CPU��Դ����
            
            self.session = ort.InferenceSession(
                self.model_path,
                sess_options=sess_options,
                providers=self.providers
            )
            
            # ��ȡģ����Ϣ
            model_inputs = self.session.get_inputs()
            model_outputs = self.session.get_outputs()
            
            self.input_name = model_inputs[0].name
            self.output_name = model_outputs[0].name
            self.input_shape = model_inputs[0].shape
            
            logger.info(f"Model loaded successfully")
            logger.info(f"Input: {self.input_name}, Shape: {self.input_shape}")
            logger.info(f"Output: {self.output_name}")
            logger.info(f"Device: {ort.get_device()}")
            
            # Ԥ��ģ��
            self._warm_up()
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise
    
    def _warm_up(self):
        """Ԥ��ģ��"""
        try:
            dummy_input = np.random.randn(1, 3, 224, 224).astype(np.float32)
            for _ in range(3):  # Ԥ��3��
                _ = self.session.run([self.output_name], {self.input_name: dummy_input})
            logger.info("Model warm-up completed")
        except Exception as e:
            logger.warning(f"Model warm-up failed: {e}")
    
    def preprocess(self, image_data: bytes) -> np.ndarray:
        """Ԥ����ͼ������"""
        try:
            # ���ֽ�����ת��Ϊnumpy����
            image_array = np.frombuffer(image_data, np.uint8)
            
            # ����ͼ��
            image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
            if image is None:
                raise ValueError("Failed to decode image")
            
            # ת����ɫ�ռ� BGR -> RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # �����ߴ�
            image = cv2.resize(image, config.model.input_size)
            
            # ��һ�� [0, 255] -> [0, 1]
            image = image.astype(np.float32) / 255.0
            
            # ��׼�� (ImageNetͳ����)
            mean = np.array(config.model.mean)
            std = np.array(config.model.std)
            image = (image - mean) / std
            
            # ת��ά��: HWC -> CHW
            image = image.transpose(2, 0, 1)
            
            # ��������ά��
            image = np.expand_dims(image, axis=0)
            
            return image
            
        except Exception as e:
            logger.error(f"Image preprocessing failed: {e}")
            raise
    
    def predict(self, image_data: bytes) -> Dict[str, Any]:
        """ִ������Ԥ��"""
        start_time = time.time()
        
        try:
            # Ԥ����
            preprocess_start = time.time()
            input_tensor = self.preprocess(image_data)
            preprocess_time = time.time() - preprocess_start
            
            # ���� (�̰߳�ȫ)
            with self._lock:
                inference_start = time.time()
                outputs = self.session.run(
                    [self.output_name], 
                    {self.input_name: input_tensor}
                )
                inference_time = time.time() - inference_start
            
            # ����
            postprocess_start = time.time()
            predictions = self._postprocess(outputs[0])
            postprocess_time = time.time() - postprocess_start
            
            total_time = time.time() - start_time
            
            # ����ͳ����Ϣ
            with self._lock:
                self.stats['total_inferences'] += 1
                self.stats['total_time'] += total_time
                self.stats['last_inference_time'] = total_time
            
            result = {
                'predictions': [pred.__dict__ for pred in predictions],
                'timing': {
                    'preprocess_ms': round(preprocess_time * 1000, 2),
                    'inference_ms': round(inference_time * 1000, 2),
                    'postprocess_ms': round(postprocess_time * 1000, 2),
                    'total_ms': round(total_time * 1000, 2)
                },
                'device': ort.get_device(),
                'status': 'success'
            }
            
            logger.info(f"Inference completed in {result['timing']['total_ms']}ms")
            return result
            
        except Exception as e:
            logger.error(f"Inference failed: {e}")
            return {
                'error': str(e),
                'status': 'error'
            }
    
    def _postprocess(self, outputs: np.ndarray) -> List[PredictionResult]:
        """����ģ�����"""
        try:
            # Ӧ��softmax��ȡ����
            probabilities = self._softmax(outputs[0])
            
            # ��ȡTop-5Ԥ����
            top5_indices = np.argsort(probabilities)[-5:][::-1]
            top5_probabilities = probabilities[top5_indices]
            
            # ����Ӧ��ʹ����ʵ��ImageNet��ǩ
            # Ϊ��ʾʹ�������ǩ
            results = []
            for i, (idx, prob) in enumerate(zip(top5_indices, top5_probabilities)):
                results.append(PredictionResult(
                    class_id=int(idx),
                    class_name=f'class_{idx}',
                    confidence=float(prob),
                    confidence_percentage=round(float(prob) * 100, 2)
                ))
            
            return results
            
        except Exception as e:
            logger.error(f"Postprocessing failed: {e}")
            raise
    
    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        """Softmax����"""
        exp_x = np.exp(x - np.max(x))
        return exp_x / np.sum(exp_x)
    
    def get_stats(self) -> Dict[str, Any]:
        """��ȡ����ͳ����Ϣ"""
        with self._lock:
            avg_time = (self.stats['total_time'] / self.stats['total_inferences'] * 1000 
                       if self.stats['total_inferences'] > 0 else 0)
            
            return {
                'total_inferences': self.stats['total_inferences'],
                'average_inference_time_ms': round(avg_time, 2),
                'last_inference_time_ms': round(self.stats['last_inference_time'] * 1000, 2),
                'device': ort.get_device(),
                'model_loaded': self.session is not None
            }
    
    def batch_predict(self, images_data: List[bytes]) -> List[Dict[str, Any]]:
        """����Ԥ�� (�򻯰�)"""
        results = []
        for image_data in images_data:
            results.append(self.predict(image_data))
        return results