from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.openapi.docs import get_swagger_ui_html
import uvicorn
import time
import logging
from typing import List, Optional
import asyncio
from concurrent.futures import ThreadPoolExecutor

from config import config
from model_manager import ModelManager

# ������־
config.setup_logging()
logger = logging.getLogger(__name__)

# ����FastAPIӦ��
app = FastAPI(
    title="Docker����������API",
    description="����ONNX Runtime�ĸ�����ͼ�������������",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# ����CORS�м��
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ȫ�ֱ���
model_manager = ModelManager()
executor = ThreadPoolExecutor(max_workers=4)

@app.on_event("startup")
async def startup_event():
    """Ӧ�������¼�"""
    logger.info("Starting Docker Inference Engine API...")
    logger.info(f"Server running on {config.server.host}:{config.server.port}")
    logger.info(f"Model path: {config.model.model_path}")
    logger.info(f"Device: {config.inference.device}")

@app.on_event("shutdown")
async def shutdown_event():
    """Ӧ�ùر��¼�"""
    logger.info("Shutting down Docker Inference Engine API...")
    model_manager.stop_watcher()
    executor.shutdown()

@app.get("/", include_in_schema=False)
async def root():
    """��·��"""
    return {"message": "Docker Inference Engine API", "status": "running"}

@app.get("/health")
async def health_check():
    """�������˵�"""
    status = model_manager.get_status()
    
    if status['model_loaded']:
        return JSONResponse(
            content={
                "status": "healthy",
                "timestamp": time.time(),
                "model_loaded": True,
                "device": status['engine_stats']['device']
            },
            status_code=200
        )
    else:
        return JSONResponse(
            content={
                "status": "unhealthy",
                "timestamp": time.time(),
                "model_loaded": False,
                "error": "Model not loaded"
            },
            status_code=503
        )

@app.get("/status")
async def get_status():
    """��ȡ����״̬"""
    status = model_manager.get_status()
    return {
        "service": "Docker Inference Engine",
        "version": "1.0.0",
        "timestamp": time.time(),
        **status
    }

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """����ͼƬԤ��˵�"""
    # ��֤�ļ�����
    allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/bmp']
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=400, 
            detail=f"File type not supported. Allowed types: {allowed_types}"
        )
    
    # ��ȡ�ļ�����
    try:
        image_data = await file.read()
        
        # ��֤�ļ���С (���10MB)
        if len(image_data) > 10 * 1024 * 1024:
            raise HTTPException(
                status_code=400,
                detail="File too large. Maximum size is 10MB."
            )
        
        # ��ȡ��������
        engine = model_manager.get_engine()
        if not engine:
            raise HTTPException(
                status_code=503,
                detail="Model not loaded. Service unavailable."
            )
        
        # ���̳߳���ִ������ (���������¼�ѭ��)
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(executor, engine.predict, image_data)
        
        if result['status'] == 'error':
            raise HTTPException(status_code=500, detail=result['error'])
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Prediction request failed: {e}")
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@app.post("/batch_predict")
async def batch_predict(files: List[UploadFile] = File(...)):
    """����Ԥ��˵�"""
    # ����������С
    if len(files) > 10:
        raise HTTPException(
            status_code=400,
            detail="Too many files. Maximum batch size is 10."
        )
    
    # ��֤�����ļ�
    allowed_types = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/bmp']
    for file in files:
        if file.content_type not in allowed_types:
            raise HTTPException(
                status_code=400,
                detail=f"File {file.filename} has unsupported type. Allowed types: {allowed_types}"
            )
    
    try:
        # ��ȡ�����ļ�����
        images_data = []
        filenames = []
        
        for file in files:
            image_data = await file.read()
            
            # ��֤�ļ���С
            if len(image_data) > 10 * 1024 * 1024:
                raise HTTPException(
                    status_code=400,
                    detail=f"File {file.filename} is too large. Maximum size is 10MB."
                )
            
            images_data.append(image_data)
            filenames.append(file.filename)
        
        # ��ȡ��������
        engine = model_manager.get_engine()
        if not engine:
            raise HTTPException(
                status_code=503,
                detail="Model not loaded. Service unavailable."
            )
        
        # ִ����������
        loop = asyncio.get_event_loop()
        results = await loop.run_in_executor(
            executor, engine.batch_predict, images_data
        )
        
        # �����ļ��������
        for i, result in enumerate(results):
            result['filename'] = filenames[i]
        
        return {
            "batch_id": f"batch_{int(time.time())}",
            "total_files": len(files),
            "results": results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Batch prediction failed: {e}")
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")

@app.get("/metrics")
async def get_metrics():
    """��ȡ����ָ�� (Prometheus��ʽ)"""
    engine = model_manager.get_engine()
    if not engine:
        return ""
    
    stats = engine.get_stats()
    
    metrics = f"""# HELP inference_engine_total_inferences Total number of inferences performed
# TYPE inference_engine_total_inferences counter
inference_engine_total_inferences {stats['total_inferences']}

# HELP inference_engine_average_inference_time_ms Average inference time in milliseconds
# TYPE inference_engine_average_inference_time_ms gauge
inference_engine_average_inference_time_ms {stats['average_inference_time_ms']}

# HELP inference_engine_last_inference_time_ms Last inference time in milliseconds
# TYPE inference_engine_last_inference_time_ms gauge
inference_engine_last_inference_time_ms {stats['last_inference_time_ms']}

# HELP inference_engine_device Device used for inference
# TYPE inference_engine_device gauge
inference_engine_device{{device="{stats['device']}"}} 1
"""
    
    return metrics

if __name__ == "__main__":
    uvicorn.run(
        "app:app",
        host=config.server.host,
        port=config.server.port,
        workers=config.server.workers,
        log_level=config.server.log_level.lower(),
        access_log=True
    )