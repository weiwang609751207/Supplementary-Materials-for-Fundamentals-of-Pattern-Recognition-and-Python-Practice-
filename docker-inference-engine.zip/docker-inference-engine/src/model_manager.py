import os
import time
import logging
from typing import Optional, Dict, Any
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from inference_engine import InferenceEngine
from config import config

logger = logging.getLogger(__name__)

class ModelWatcher(FileSystemEventHandler):
    """ģ���ļ�������"""
    
    def __init__(self, model_path: str, callback: callable):
        self.model_path = model_path
        self.callback = callback
        self.last_modified = os.path.getmtime(model_path) if os.path.exists(model_path) else 0
    
    def on_modified(self, event):
        if event.src_path == self.model_path:
            current_modified = os.path.getmtime(self.model_path)
            if current_modified != self.last_modified:
                self.last_modified = current_modified
                logger.info(f"Model file changed: {self.model_path}")
                self.callback()

class ModelManager:
    """ģ�͹�����"""
    
    def __init__(self):
        self.engine: Optional[InferenceEngine] = None
        self.observer: Optional[Observer] = None
        self.load_model()
        
        # �����ļ�������
        if os.path.exists(config.model.model_path):
            self.start_watcher()
    
    def load_model(self):
        """����ģ��"""
        try:
            if not os.path.exists(config.model.model_path):
                logger.warning(f"Model file not found: {config.model.model_path}")
                return
            
            self.engine = InferenceEngine(
                model_path=config.model.model_path,
                providers=config.inference.providers
            )
            logger.info("Model loaded successfully")
            
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            self.engine = None
    
    def reload_model(self):
        """���¼���ģ��"""
        logger.info("Reloading model...")
        self.engine = None
        time.sleep(1)  # ȷ���ļ�д�����
        self.load_model()
    
    def start_watcher(self):
        """����ģ���ļ�������"""
        try:
            event_handler = ModelWatcher(config.model.model_path, self.reload_model)
            self.observer = Observer()
            self.observer.schedule(
                event_handler, 
                path=os.path.dirname(config.model.model_path), 
                recursive=False
            )
            self.observer.start()
            logger.info("Model file watcher started")
        except Exception as e:
            logger.error(f"Failed to start model watcher: {e}")
    
    def stop_watcher(self):
        """ֹͣģ���ļ�������"""
        if self.observer:
            self.observer.stop()
            self.observer.join()
            logger.info("Model file watcher stopped")
    
    def get_engine(self) -> Optional[InferenceEngine]:
        """��ȡ��������ʵ��"""
        return self.engine
    
    def get_status(self) -> Dict[str, Any]:
        """��ȡģ��״̬"""
        if self.engine:
            return {
                'model_loaded': True,
                'model_path': config.model.model_path,
                'engine_stats': self.engine.get_stats()
            }
        else:
            return {
                'model_loaded': False,
                'model_path': config.model.model_path,
                'error': 'Model not loaded'
            }